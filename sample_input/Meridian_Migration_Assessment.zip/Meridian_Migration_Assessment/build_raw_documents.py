"""Builds the "raw" input documents for Meridian Outfitters - the kind of
exports a real IT team would actually hand over (an inventory spreadsheet,
an integration map, a narrative landscape overview), in business language
rather than the ServiceNode/DependencyEdge graph schema.

Reads ../Meridian_Sample_Graph/nodes.csv + edges.csv as the single source of
truth (same numbers, same story) and reshapes them into:
  - IT_Application_Inventory.xlsx
  - System_Integration_Map.xlsx
  - IT_Landscape_Overview.pdf

Mirrors the relationship between Northwind_Migration_Assessment (raw corpus)
and Northwind_Expected_Graph (the computed answer) - this folder is the
"question", Meridian_Sample_Graph is the "answer".

Usage: python build_raw_documents.py
"""
import csv
import os

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from reportlab.lib import colors
from reportlab.lib.enums import TA_JUSTIFY
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

HERE = os.path.dirname(os.path.abspath(__file__))
GRAPH_DIR = os.path.join(HERE, "..", "Meridian_Sample_Graph")

HEADER_FILL = PatternFill(start_color="0D1B1A", end_color="0D1B1A", fill_type="solid")
HEADER_FONT = Font(color="FFFFFF", bold=True)

OWNER_BY_ID = {
    "app_01": "Finance & Operations", "app_02": "E-Commerce", "app_03": "E-Commerce",
    "app_04": "E-Commerce", "app_05": "E-Commerce", "app_06": "Merchandising",
    "app_07": "Supply Chain", "app_08": "Merchandising", "app_09": "Supply Chain",
    "app_10": "E-Commerce", "app_11": "Customer Experience", "app_12": "Customer Experience",
    "app_13": "Marketing", "app_14": "Supply Chain", "app_15": "Merchandising",
    "app_16": "Customer Experience", "app_17": "IT Operations", "app_18": "IT Operations",
    "app_19": "Supply Chain", "app_20": "Store Operations", "app_21": "Finance & Analytics",
}
SYSTEM_TYPE_LABEL = {
    "Monolith": "Core Application", "Microservice": "Application Service",
    "Database": "Data Store", "Queue": "Integration / Messaging",
}
INTEGRATION_TYPE_LABEL = {
    "Sync": "Real-time API call", "Async": "Async event/message",
    "DB": "Direct database link", "MQ": "Message queue",
}


def read_csv(name: str):
    with open(os.path.join(GRAPH_DIR, name), newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def style_sheet(ws, header, rows, widths=None):
    ws.append(header)
    for col_idx in range(1, len(header) + 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center")
    for row in rows:
        ws.append(row)
    for col_idx, name in enumerate(header, start=1):
        letter = get_column_letter(col_idx)
        if widths and name in widths:
            ws.column_dimensions[letter].width = widths[name]
        else:
            max_len = max([len(name)] + [len(str(r[col_idx - 1])) for r in rows]) if rows else len(name)
            ws.column_dimensions[letter].width = min(max(max_len + 3, 10), 46)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions


def build_inventory(nodes):
    wb = Workbook()
    ws = wb.active
    ws.title = "Application Inventory"
    header = [
        "System ID", "System Name", "Business Owner", "System Type", "Technology / Platform",
        "Business Criticality", "Migration Complexity", "Current Status",
        "Annual Hosting Cost ($)", "Estimated Migration Cost ($)", "Estimated Migration Duration (Days)",
        "Monthly Revenue Dependency ($)", "Annual Downtime Incidents",
    ]
    rows = []
    for n in nodes:
        incidents = max(1, round(float(n["failure_probability"]) * 14))
        rows.append([
            n["id"], n["name"], OWNER_BY_ID[n["id"]], SYSTEM_TYPE_LABEL[n["type"]], n["runtime"],
            n["business_value"], n["migration_complexity"], n["status"],
            int(float(n["annual_cost"])), int(float(n["base_cost"])), int(n["base_duration"]),
            int(float(n["revenue_impact"])), incidents,
        ])
    widths = {"System Name": 30, "Technology / Platform": 30, "Business Owner": 20}
    style_sheet(ws, header, rows, widths)
    for col in ("I", "J", "L"):
        for cell in ws[col][1:]:
            cell.number_format = "$#,##0"
    wb.save(os.path.join(HERE, "IT_Application_Inventory.xlsx"))


def build_integration_map(nodes, edges):
    name_by_id = {n["id"]: n["name"] for n in nodes}
    wb = Workbook()
    ws = wb.active
    ws.title = "Integration Map"
    header = ["Source System", "Target System", "Integration Type", "Criticality", "Notes"]
    rows = []
    for e in edges:
        src, tgt = name_by_id[e["source"]], name_by_id[e["target"]]
        itype = INTEGRATION_TYPE_LABEL[e["type"]]
        if e["type"] == "Sync":
            note = f"{src} calls {tgt} synchronously at request time."
        elif e["type"] == "Async":
            note = f"{src} publishes events consumed by {tgt} asynchronously."
        elif e["type"] == "MQ":
            note = f"{src} and {tgt} communicate via a shared message queue."
        else:
            note = f"{src} reads/writes {tgt}'s data directly."
        rows.append([src, tgt, itype, e["criticality"], note])
    widths = {"Source System": 28, "Target System": 28, "Notes": 55}
    style_sheet(ws, header, rows, widths)
    wb.save(os.path.join(HERE, "System_Integration_Map.xlsx"))


def build_overview_pdf(nodes, edges):
    doc = SimpleDocTemplate(
        os.path.join(HERE, "IT_Landscape_Overview.pdf"),
        pagesize=LETTER, topMargin=0.9 * inch, bottomMargin=0.9 * inch,
        leftMargin=0.9 * inch, rightMargin=0.9 * inch,
    )
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleX", parent=styles["Title"], fontSize=20, spaceAfter=4)
    subtitle_style = ParagraphStyle("Subtitle", parent=styles["Normal"], fontSize=10.5, textColor=colors.grey, spaceAfter=18)
    h2 = ParagraphStyle("H2", parent=styles["Heading2"], spaceBefore=14, spaceAfter=6)
    body = ParagraphStyle("BodyX", parent=styles["BodyText"], alignment=TA_JUSTIFY, leading=15, spaceAfter=8)

    total_hosting = sum(int(float(n["annual_cost"])) for n in nodes)
    monolith = next(n for n in nodes if n["type"] == "Monolith")
    high_risk = sorted(nodes, key=lambda n: float(n["failure_probability"]), reverse=True)[:3]
    high_revenue = sorted(nodes, key=lambda n: float(n["revenue_impact"]), reverse=True)[:3]

    story = [
        Paragraph("Meridian Outfitters", title_style),
        Paragraph("IT Landscape Overview - prepared for cloud migration assessment kickoff", subtitle_style),
        Paragraph("Company background", h2),
        Paragraph(
            "Meridian Outfitters is a mid-size outdoor and sporting-goods retailer generating "
            "approximately $180M in annual revenue across web, mobile, and in-store channels. "
            "The company operates 40+ retail locations alongside its e-commerce storefront and "
            "mobile app, all of which ultimately settle orders and inventory through a single "
            "on-premises ERP system that has been in place for over a decade.",
            body,
        ),
        Paragraph("Current state", h2),
        Paragraph(
            f"The commerce platform is organized as a set of {sum(1 for n in nodes if n['type'] == 'Microservice')} "
            "application services layered around one legacy core system, "
            f"“{monolith['name']}”, which remains the system of record for both order and inventory data. "
            "Every customer-facing channel - the web storefront, the mobile app, and the in-store point-of-sale "
            "gateway - ultimately depends on this system, either directly or through the Order Management and "
            "Inventory services built around it. Supporting data is held across three databases (orders, product "
            "catalog, and customer), a session cache, and an order-events queue used to fan out fulfillment and "
            f"shipping updates. Combined annual hosting spend across the estate is approximately ${total_hosting:,}.",
            body,
        ),
        Paragraph("Why this system matters to the business", h2),
        Paragraph(
            "Three characteristics of the current architecture are the main drivers behind the migration effort:",
            body,
        ),
        Paragraph(
            f"<b>Concentration risk.</b> “{monolith['name']}” is depended on by the Inventory, Order "
            "Management, and Store POS systems, and has both the highest migration complexity and the highest "
            "incident history in the estate - it is the single component most likely to cause a company-wide "
            "outage if something goes wrong.",
            body,
        ),
        Paragraph(
            "<b>Revenue concentration.</b> "
            + ", ".join(f"{n['name']} (~${int(float(n['revenue_impact'])):,}/mo)" for n in high_revenue)
            + " together account for the largest share of revenue that would be at risk during an outage, "
            "and are the natural priority for careful sequencing and rollback planning.",
            body,
        ),
        Paragraph(
            "<b>Reliability history.</b> "
            + ", ".join(n["name"] for n in high_risk)
            + " have the highest incident counts of any systems in the estate over the past year, and are "
            "flagged for early attention regardless of migration order.",
            body,
        ),
        Paragraph("Scope of this document set", h2),
        Paragraph(
            "This overview accompanies two structured exports: <b>IT_Application_Inventory.xlsx</b>, a "
            f"system-by-system inventory ({len(nodes)} entries) covering ownership, technology, cost, and "
            f"criticality; and <b>System_Integration_Map.xlsx</b>, a listing of the {len(edges)} known "
            "integrations between those systems, their type, and criticality. Together they form the input "
            "corpus for the migration assessment - nothing here has been pre-computed into a dependency graph "
            "or risk score; that analysis is the assessment's job to produce.",
            body,
        ),
    ]
    doc.build(story)


def main():
    nodes = read_csv("nodes.csv")
    edges = read_csv("edges.csv")
    build_inventory(nodes)
    build_integration_map(nodes, edges)
    build_overview_pdf(nodes, edges)
    print("Wrote IT_Application_Inventory.xlsx, System_Integration_Map.xlsx, IT_Landscape_Overview.pdf")


if __name__ == "__main__":
    main()
