# Meridian Migration Assessment — raw input documents

The "question" to go with `Meridian_Sample_Graph`'s "answer" - the same 21-system,
34-integration Meridian Outfitters scenario, but shaped as the kind of raw exports a
real IT team would actually hand over at the start of an assessment, not a pre-built
dependency graph. Mirrors how `Northwind_Migration_Assessment` (raw corpus) relates to
`Northwind_Expected_Graph` (the computed baseline) elsewhere in this repo.

## Files

| File | What it is |
|---|---|
| `IT_Application_Inventory.xlsx` | One row per system - owner, technology, cost, criticality, incident history. Business language throughout (no `business_value`/`migration_complexity`-style schema field names). |
| `System_Integration_Map.xlsx` | One row per integration - source/target system, integration type, criticality, a one-line description. |
| `IT_Landscape_Overview.pdf` | A short prose overview (company background, current-state architecture, why it matters) - the kind of narrative document that needs to be *read*, not parsed as a table. |
| `build_raw_documents.py` | Regenerates all three from `../Meridian_Sample_Graph/nodes.csv` + `edges.csv` - that folder stays the single source of truth so the two never drift apart. |

## Relationship to Meridian_Sample_Graph

Same underlying data, two different shapes:

- **This folder** - realistic source documents. Upload these to an assessment (Documents
  tab) and run Document Discovery to see the pipeline reconstruct the graph itself.
- **`Meridian_Sample_Graph`** - the pre-built graph (`nodes.csv`/`edges.csv`/`graph.json`)
  plus `seed_assessment.py`, which persists it directly via the API for an instant,
  deterministic result when you don't want to wait on document extraction.

Regenerate this folder any time the graph data changes:

```
python build_raw_documents.py
```
